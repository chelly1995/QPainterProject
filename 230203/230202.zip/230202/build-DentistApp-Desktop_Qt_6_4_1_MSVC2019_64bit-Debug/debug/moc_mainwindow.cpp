/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../230201/mainwindow.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[60];
    char stringdata0[11];
    char stringdata1[15];
    char stringdata2[1];
    char stringdata3[16];
    char stringdata4[11];
    char stringdata5[17];
    char stringdata6[15];
    char stringdata7[16];
    char stringdata8[9];
    char stringdata9[33];
    char stringdata10[28];
    char stringdata11[29];
    char stringdata12[32];
    char stringdata13[33];
    char stringdata14[32];
    char stringdata15[18];
    char stringdata16[15];
    char stringdata17[5];
    char stringdata18[13];
    char stringdata19[27];
    char stringdata20[28];
    char stringdata21[30];
    char stringdata22[31];
    char stringdata23[27];
    char stringdata24[27];
    char stringdata25[30];
    char stringdata26[5];
    char stringdata27[31];
    char stringdata28[26];
    char stringdata29[28];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 14),  // "sig_doctorInfo"
        QT_MOC_LITERAL(26, 0),  // ""
        QT_MOC_LITERAL(27, 15),  // "sig_zoomKeySend"
        QT_MOC_LITERAL(43, 10),  // "selectItem"
        QT_MOC_LITERAL(54, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(71, 14),  // "previousScreen"
        QT_MOC_LITERAL(86, 15),  // "slot_doctorInfo"
        QT_MOC_LITERAL(102, 8),  // "DoctorID"
        QT_MOC_LITERAL(111, 32),  // "on_layoutClearPushButton_clicked"
        QT_MOC_LITERAL(144, 27),  // "on_zoomInToolButton_clicked"
        QT_MOC_LITERAL(172, 28),  // "on_zoomOutToolButton_clicked"
        QT_MOC_LITERAL(201, 31),  // "on_leftRotateToolButton_clicked"
        QT_MOC_LITERAL(233, 32),  // "on_rightRotateToolButton_clicked"
        QT_MOC_LITERAL(266, 31),  // "on_sourceSizePushButton_clicked"
        QT_MOC_LITERAL(298, 17),  // "layoutSizeChanged"
        QT_MOC_LITERAL(316, 14),  // "QGraphicsView*"
        QT_MOC_LITERAL(331, 4),  // "grid"
        QT_MOC_LITERAL(336, 12),  // "DoubleWidget"
        QT_MOC_LITERAL(349, 26),  // "on_brushToolButton_clicked"
        QT_MOC_LITERAL(376, 27),  // "on_circleToolButton_clicked"
        QT_MOC_LITERAL(404, 29),  // "on_triangleToolButton_clicked"
        QT_MOC_LITERAL(434, 30),  // "on_rectangleToolButton_clicked"
        QT_MOC_LITERAL(465, 26),  // "on_arrowToolButton_clicked"
        QT_MOC_LITERAL(492, 26),  // "on_colorToolButton_clicked"
        QT_MOC_LITERAL(519, 29),  // "on_doubleSpinBox_valueChanged"
        QT_MOC_LITERAL(549, 4),  // "arg1"
        QT_MOC_LITERAL(554, 30),  // "on_drawClearPushButton_clicked"
        QT_MOC_LITERAL(585, 25),  // "on_linetoolButton_clicked"
        QT_MOC_LITERAL(611, 27)   // "on_cursortoolButton_clicked"
    },
    "MainWindow",
    "sig_doctorInfo",
    "",
    "sig_zoomKeySend",
    "selectItem",
    "QListWidgetItem*",
    "previousScreen",
    "slot_doctorInfo",
    "DoctorID",
    "on_layoutClearPushButton_clicked",
    "on_zoomInToolButton_clicked",
    "on_zoomOutToolButton_clicked",
    "on_leftRotateToolButton_clicked",
    "on_rightRotateToolButton_clicked",
    "on_sourceSizePushButton_clicked",
    "layoutSizeChanged",
    "QGraphicsView*",
    "grid",
    "DoubleWidget",
    "on_brushToolButton_clicked",
    "on_circleToolButton_clicked",
    "on_triangleToolButton_clicked",
    "on_rectangleToolButton_clicked",
    "on_arrowToolButton_clicked",
    "on_colorToolButton_clicked",
    "on_doubleSpinBox_valueChanged",
    "arg1",
    "on_drawClearPushButton_clicked",
    "on_linetoolButton_clicked",
    "on_cursortoolButton_clicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  152,    2, 0x06,    1 /* Public */,
       3,    0,  155,    2, 0x06,    3 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    1,  156,    2, 0x0a,    4 /* Public */,
       6,    0,  159,    2, 0x0a,    6 /* Public */,
       7,    1,  160,    2, 0x0a,    7 /* Public */,
       9,    0,  163,    2, 0x08,    9 /* Private */,
      10,    0,  164,    2, 0x08,   10 /* Private */,
      11,    0,  165,    2, 0x08,   11 /* Private */,
      12,    0,  166,    2, 0x08,   12 /* Private */,
      13,    0,  167,    2, 0x08,   13 /* Private */,
      14,    0,  168,    2, 0x08,   14 /* Private */,
      15,    1,  169,    2, 0x08,   15 /* Private */,
      18,    1,  172,    2, 0x08,   17 /* Private */,
      19,    0,  175,    2, 0x08,   19 /* Private */,
      20,    0,  176,    2, 0x08,   20 /* Private */,
      21,    0,  177,    2, 0x08,   21 /* Private */,
      22,    0,  178,    2, 0x08,   22 /* Private */,
      23,    0,  179,    2, 0x08,   23 /* Private */,
      24,    0,  180,    2, 0x08,   24 /* Private */,
      25,    1,  181,    2, 0x08,   25 /* Private */,
      27,    0,  184,    2, 0x08,   27 /* Private */,
      28,    0,  185,    2, 0x08,   28 /* Private */,
      29,    0,  186,    2, 0x08,   29 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 5,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,   26,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'sig_doctorInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'sig_zoomKeySend'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectItem'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'previousScreen'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'slot_doctorInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'on_layoutClearPushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zoomInToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_zoomOutToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_leftRotateToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_rightRotateToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_sourceSizePushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'layoutSizeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsView *, std::false_type>,
        // method 'DoubleWidget'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsView *, std::false_type>,
        // method 'on_brushToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_circleToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_triangleToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_rectangleToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_arrowToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_colorToolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_doubleSpinBox_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'on_drawClearPushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_linetoolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_cursortoolButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->sig_doctorInfo((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->sig_zoomKeySend(); break;
        case 2: _t->selectItem((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 3: _t->previousScreen(); break;
        case 4: _t->slot_doctorInfo((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->on_layoutClearPushButton_clicked(); break;
        case 6: _t->on_zoomInToolButton_clicked(); break;
        case 7: _t->on_zoomOutToolButton_clicked(); break;
        case 8: _t->on_leftRotateToolButton_clicked(); break;
        case 9: _t->on_rightRotateToolButton_clicked(); break;
        case 10: _t->on_sourceSizePushButton_clicked(); break;
        case 11: _t->layoutSizeChanged((*reinterpret_cast< std::add_pointer_t<QGraphicsView*>>(_a[1]))); break;
        case 12: _t->DoubleWidget((*reinterpret_cast< std::add_pointer_t<QGraphicsView*>>(_a[1]))); break;
        case 13: _t->on_brushToolButton_clicked(); break;
        case 14: _t->on_circleToolButton_clicked(); break;
        case 15: _t->on_triangleToolButton_clicked(); break;
        case 16: _t->on_rectangleToolButton_clicked(); break;
        case 17: _t->on_arrowToolButton_clicked(); break;
        case 18: _t->on_colorToolButton_clicked(); break;
        case 19: _t->on_doubleSpinBox_valueChanged((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 20: _t->on_drawClearPushButton_clicked(); break;
        case 21: _t->on_linetoolButton_clicked(); break;
        case 22: _t->on_cursortoolButton_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(QString );
            if (_t _q_method = &MainWindow::sig_doctorInfo; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (_t _q_method = &MainWindow::sig_zoomKeySend; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 23;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::sig_doctorInfo(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::sig_zoomKeySend()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
