#include "item.h"

#include <QGraphicsItem>

item::item(QWidget *parent)
    : QGraphicsItem{parent}
{

}
