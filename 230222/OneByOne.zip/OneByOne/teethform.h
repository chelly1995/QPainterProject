#ifndef TEETHFORM_H
#define TEETHFORM_H


#include <QWidget>

#include <QLabel>


namespace Ui {
class TeethForm;
}

class TeethForm : public QWidget
{
    Q_OBJECT

public:
    explicit TeethForm(QWidget *parent = nullptr);
    ~TeethForm();


private slots:
    /* Top Left Teeth 임플란트를 선택했을 때 실행되는 슬롯 */
    void on_toolButton_11_clicked();
    void on_toolButton_12_clicked();
    void on_toolButton_13_clicked();
    void on_toolButton_14_clicked();
    void on_toolButton_15_clicked();
    void on_toolButton_16_clicked();
    void on_toolButton_17_clicked();

    /* Top Right Teeth 임플란트를 선택했을 때 실행되는 슬롯 */
    void on_toolButton_21_clicked();
    void on_toolButton_22_clicked();
    void on_toolButton_23_clicked();
    void on_toolButton_24_clicked();
    void on_toolButton_25_clicked();
    void on_toolButton_26_clicked();
    void on_toolButton_27_clicked();

    /* Bottom Right Teeth 임플란트를 선택했을 때 실행되는 슬롯 */
    void on_toolButton_31_clicked();
    void on_toolButton_32_clicked();
    void on_toolButton_33_clicked();
    void on_toolButton_34_clicked();
    void on_toolButton_35_clicked();
    void on_toolButton_36_clicked();
    void on_toolButton_37_clicked();

    /* Bottom Left Teeth 임플란트를 선택했을 때 실행되는 슬롯 */
    void on_toolButton_41_clicked();
    void on_toolButton_42_clicked();
    void on_toolButton_43_clicked();
    void on_toolButton_44_clicked();
    void on_toolButton_45_clicked();
    void on_toolButton_46_clicked();
    void on_toolButton_47_clicked();


private:
    Ui::TeethForm *ui;


signals:
    /* Top Left Teeth */
    void sig_11(QPixmap*);  // 치아 11번 이미지를 시그널로 전달
    void sig_12(QPixmap*);  // 치아 12번 이미지를 시그널로 전달
    void sig_13(QPixmap*);  // 치아 13번 이미지를 시그널로 전달
    void sig_14(QPixmap*);  // 치아 14번 이미지를 시그널로 전달
    void sig_15(QPixmap*);  // 치아 15번 이미지를 시그널로 전달
    void sig_16(QPixmap*);  // 치아 16번 이미지를 시그널로 전달
    void sig_17(QPixmap*);  // 치아 17번 이미지를 시그널로 전달

    /* Top Right Teeth */
    void sig_21(QPixmap*);  // 치아 21번 이미지를 시그널로 전달
    void sig_22(QPixmap*);  // 치아 22번 이미지를 시그널로 전달
    void sig_23(QPixmap*);  // 치아 23번 이미지를 시그널로 전달
    void sig_24(QPixmap*);  // 치아 24번 이미지를 시그널로 전달
    void sig_25(QPixmap*);  // 치아 25번 이미지를 시그널로 전달
    void sig_26(QPixmap*);  // 치아 26번 이미지를 시그널로 전달
    void sig_27(QPixmap*);  // 치아 27번 이미지를 시그널로 전달

    /* Bottom Right Teeth */
    void sig_31(QPixmap*);  // 치아 31번 이미지를 시그널로 전달
    void sig_32(QPixmap*);  // 치아 32번 이미지를 시그널로 전달
    void sig_33(QPixmap*);  // 치아 33번 이미지를 시그널로 전달
    void sig_34(QPixmap*);  // 치아 34번 이미지를 시그널로 전달
    void sig_35(QPixmap*);  // 치아 35번 이미지를 시그널로 전달
    void sig_36(QPixmap*);  // 치아 36번 이미지를 시그널로 전달
    void sig_37(QPixmap*);  // 치아 37번 이미지를 시그널로 전달

    /* Bottom Left Teeth */
    void sig_41(QPixmap*);  // 치아 41번 이미지를 시그널로 전달
    void sig_42(QPixmap*);  // 치아 42번 이미지를 시그널로 전달
    void sig_43(QPixmap*);  // 치아 43번 이미지를 시그널로 전달
    void sig_44(QPixmap*);  // 치아 44번 이미지를 시그널로 전달
    void sig_45(QPixmap*);  // 치아 45번 이미지를 시그널로 전달
    void sig_46(QPixmap*);  // 치아 46번 이미지를 시그널로 전달
    void sig_47(QPixmap*);  // 치아 47번 이미지를 시그널로 전달
};

#endif // TEETHFORM_H
