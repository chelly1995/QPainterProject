#ifndef SCENEWIDGET_H
#define SCENEWIDGET_H

#include <QGraphicsScene>
#include <QList>

class SceneWidget : public QGraphicsScene
{
    Q_OBJECT
public:
    SceneWidget(QObject *parent = nullptr);

protected:
    void mouseMoveEvent(QGraphicsSceneMouseEvent *mouseEvent) override;
    void mousePressEvent(QGraphicsSceneMouseEvent *mouseEvent) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent) override;

private:
     bool m_isDrawable;
     QList<QGraphicsPathItem*> pathList;
};

#endif // SCENEWIDGET_H
