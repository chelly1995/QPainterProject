#include "widget.h"
#include "scenewidget.h"


Widget::Widget(QWidget *parent)
    : QGraphicsView(parent)
{
    SceneWidget* scene = new SceneWidget(this);
    scene->setSceneRect(QRectF(-400, -400, 800, 800));
    scene->addLine(-400, 0, 400, 0);
    scene->addLine(0, -400, 0, 400);

    setScene(scene);
//    setDragMode(QGraphicsView::RubberBandDrag);
    resize(1024, 768);
}

Widget::~Widget()
{
}

