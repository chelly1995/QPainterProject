#include "scenewidget.h"

#include <QPainterPath>
#include <QGraphicsPathItem>
#include <QGraphicsSceneMouseEvent>

SceneWidget::SceneWidget(QObject *parent)
    : QGraphicsScene(parent), m_isDrawable(false)
{
    pathList.clear();
}

void SceneWidget::mousePressEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    QPen pen(QColor(Qt::red), 3);
    m_isDrawable = true;

    QPainterPath path;
    QGraphicsPathItem* item = addPath(path);
    item->setPen(pen);
    item->setBrush(Qt::transparent);

    path = item->path();
    path.moveTo(mouseEvent->scenePos());
    path.lineTo(mouseEvent->scenePos());
    item->setPath(path);

    pathList.append(item);
}

void SceneWidget::mouseMoveEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    if(m_isDrawable) {
        QGraphicsPathItem* item = pathList.last();
        if(item) {
            QPainterPath path = item->path();
            path.lineTo(mouseEvent->scenePos());
            item->setPath(path);
        }
    }
}

void SceneWidget::mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    Q_UNUSED(mouseEvent);
    m_isDrawable = false;
}
