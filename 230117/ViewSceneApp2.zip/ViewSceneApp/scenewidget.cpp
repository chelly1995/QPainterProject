#include "scenewidget.h"
#include "movableitem.h"

#include <QPainterPath>
#include <QGraphicsPathItem>
#include <QGraphicsSceneMouseEvent>

SceneWidget::SceneWidget(QObject *parent)
    : QGraphicsScene(parent), m_isDrawable(false)
{
    QPainterPath path;
    m_pathItem = addPath(path);
    m_pathItem->setZValue(-100);

    MovableItem* item1 = new MovableItem();
    item1->setPos(-100, 100);
    MovableItem* item2 = new MovableItem();
    item2->setPos(-100, -100);
    MovableItem* item3 = new MovableItem();
    item3->setPos(100, 100);
    addItem(item1);
    addItem(item2);
    addItem(item3);

    m_itemList.append(item1);
    m_itemList.append(item2);
    m_itemList.append(item3);

    update();
}

void SceneWidget::mousePressEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    QPen pen(QColor(Qt::red), 3);
    if(items(mouseEvent->scenePos()).isEmpty()) {
        m_isDrawable = true;

        QPainterPath path;
        QGraphicsPathItem* item = addPath(path);
        item->setPen(pen);
        item->setBrush(Qt::transparent);

        path = item->path();
        path.moveTo(mouseEvent->scenePos());
        path.lineTo(mouseEvent->scenePos());
        item->setPath(path);

        m_pathList.append(item);
    }
    QGraphicsScene::mousePressEvent(mouseEvent);
}

void SceneWidget::mouseMoveEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    if(m_isDrawable) {
        QGraphicsPathItem* item = m_pathList.last();
        if(item) {
            QPainterPath path = item->path();
            path.lineTo(mouseEvent->scenePos());
            item->setPath(path);
        }
    }
    QGraphicsScene::mouseMoveEvent(mouseEvent);
}

void SceneWidget::mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent)
{
    Q_UNUSED(mouseEvent);
    m_isDrawable = false;
    QGraphicsScene::mouseReleaseEvent(mouseEvent);
}

void SceneWidget::updateScene()
{
    qDebug("updateScene");
    QPen pen(QColor(Qt::red), 1);
    m_pathItem->setPen(pen);
    m_pathItem->setBrush(Qt::transparent);
    QPainterPath path = m_pathItem->path();

    int cnt = 0;
    path.clear();
    foreach(auto item, m_itemList) {
        qDebug() << item->scenePos();
        QPointF p = item->scenePos();
        if(cnt++ == 0) {
            path.moveTo(p.rx()+8, p.ry()+8);
        } else {
            path.lineTo(p.rx()+8, p.ry()+8);
        }

    }
    path.closeSubpath();
    m_pathItem->setPath(path);
}
