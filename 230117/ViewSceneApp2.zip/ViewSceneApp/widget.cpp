#include "widget.h"
#include "scenewidget.h"


Widget::Widget(QWidget *parent)
    : QGraphicsView(parent)
{
    SceneWidget* scene = new SceneWidget(this);
    scene->setSceneRect(QRectF(-400, -400, 800, 800));
    scene->addLine(-400, 0, 400, 0);
    scene->addLine(0, -400, 0, 400);

    connect(scene, SIGNAL(changed(const QList<QRectF> &)), scene, SLOT(updateScene()));

    setScene(scene);
//    setDragMode(QGraphicsView::RubberBandDrag);

    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
}

Widget::~Widget()
{
}

