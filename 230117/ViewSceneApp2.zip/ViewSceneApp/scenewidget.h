#ifndef SCENEWIDGET_H
#define SCENEWIDGET_H

#include <QGraphicsScene>
#include <QList>

class MovableItem;
class QGraphicsPathItem;

class SceneWidget : public QGraphicsScene
{
    Q_OBJECT
public:
    SceneWidget(QObject *parent = nullptr);

protected:
    void mouseMoveEvent(QGraphicsSceneMouseEvent *mouseEvent) override;
    void mousePressEvent(QGraphicsSceneMouseEvent *mouseEvent) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *mouseEvent) override;

private:
     bool m_isDrawable;
     QList<QGraphicsPathItem*> m_pathList;
     QList<MovableItem*> m_itemList;
     QGraphicsPathItem* m_pathItem;

public slots:
     void updateScene();
};

#endif // SCENEWIDGET_H
